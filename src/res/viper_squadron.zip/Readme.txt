------------------------------------------------------------------
VIPER SQUADRON v1.0, created by ShyWedge, 1999.
------------------------------------------------------------------

The following TrueType fonts are included:

 - Viper Squadron
 - Viper Squadron, Italic
 - Viper Squadron Solid
 - Viper Squadron Solid, Italic

v1.0 FEATURES
------------------------------------------------------------------

 - Lowercase and uppercase letters (numbers and punctuation not
   available in this version).
 - Proper spacing and kerning.

INSTRUCTIONS
------------------------------------------------------------------

 - To connect characters using Viper Squadron or Viper Squadron
   Solid, use uppercase case letters (note: because of legibility,
   not all characters are designed to connect.)

   For example, type the following line using Viper Squadron:

   baTtleStar galACtiCA


This font package is Freeware.  If you wish to distribute it,
please include all of the above fonts along with this document
and send me an e-mail to let me know which font you have so I can
inform you of the latest updates.

Thank you for downloading this font package and enjoy!

ShyFonts by ShyWedge, 1999.
------------------------------------------------------------------
Web Site:  http://welcome.to/ShyFonts
E-mail:    ShyWedge@yahoo.com